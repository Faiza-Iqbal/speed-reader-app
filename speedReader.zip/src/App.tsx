import SpeedReader from "./components/SpeedReader";

const App = () => <SpeedReader />;

export default App;
