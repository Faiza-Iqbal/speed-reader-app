export const main = "#6495edaf";
export const primary_dark = "#333";
export const primary_light = "#fff";
export const main_light = "#6495ed";
export const main_medium = "#ccc";
export const cardColors = [
  "#23aae4",
  "#e6fde4",
  "#e928cc",
  "#bbf0e1",
  "#f4ad79",
  "#677959",
  "#b186c1",
  "#32b46f",
  "#d9833f",
  "#d41c6e",
];
export const mobile = "(max-width:600px)";
