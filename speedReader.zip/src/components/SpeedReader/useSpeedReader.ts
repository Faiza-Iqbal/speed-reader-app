// lib
import { useState } from "react";
import { generateSlug } from "random-word-slugs";
import { useMediaQuery } from "@mui/material";
import { mobile } from "../../styles/colorVariables";

let intervalId: number | undefined = undefined;
let displayedWordCount = 0;
const minWordCount = 2000;
const minWordPerMin = 200;
const defaultReaderState = {
  wordCount: "",
  wordPerMin: "",
  word: "",
  readerState: "default",
};

export const useSpeedReader = () => {
  const [wordCount, SetWordCount] = useState("");
  const [wordPerMin, SetwordPerMin] = useState("");
  const [word, setWord] = useState("");
  const [readerState, setReaderState] = useState(
    defaultReaderState.readerState
  );
  const isMobile = useMediaQuery(mobile);

  const handleNumberOfWords = (e: React.ChangeEvent<HTMLInputElement>) => {
    SetWordCount(e.target.value);
  };

  const handleWordsPerMin = (e: React.ChangeEvent<HTMLInputElement>) => {
    SetwordPerMin(e.target.value);
  };

  const startReader = () => {
    setReaderState("started");

    intervalId = window.setInterval(function () {
      const slug = generateSlug(1, { format: "title" });

      setWord(slug);
      displayedWordCount++;

      if (displayedWordCount >= parseInt(wordCount)) resetReader();
    }, Math.round((60 * 1000) / parseInt(wordPerMin)));
  };

  const stopReader = () => {
    clearInterval(intervalId);
    setReaderState("stopped");
  };

  const resetReader = () => {
    clearInterval(intervalId);
    SetWordCount(defaultReaderState.wordCount);
    SetwordPerMin(defaultReaderState.wordPerMin);
    setWord(defaultReaderState.word);
    setReaderState(defaultReaderState.readerState);
    displayedWordCount = 0;
  };

  return {
    minWordCount,
    minWordPerMin,
    word,
    readerState,
    wordCount,
    wordPerMin,
    isMobile,
    handleNumberOfWords,
    handleWordsPerMin,
    startReader,
    stopReader,
  };
};
