// lib
import { Box, Container } from "@mui/material";

// src
import ActionButton from "../ActionButton";
import DisplayCard from "../DisplayCard";
import Header from "../Header/Header";
import NumberInput from "../NumberInput";
import { useSpeedReader } from "./useSpeedReader";

import { useStyles } from "./SpeedReaderStyled.style";

const SpeedReader = () => {
  const classes = useStyles();
  const {
    minWordCount,
    minWordPerMin,
    word,
    readerState,
    wordCount,
    wordPerMin,
    isMobile,
    handleNumberOfWords,
    handleWordsPerMin,
    startReader,
    stopReader,
  } = useSpeedReader();

  return (
    <Box>
      <Header>
        <h1> Speed Reader</h1>
      </Header>
      <Container sx={{ p: 8 }}>
        {readerState === "default" && (
          <Box
            className={
              isMobile ? classes.verticalAligned : classes.marginAutoContainer
            }
          >
            <NumberInput
              handleChange={handleNumberOfWords}
              inputProps={{
                min: 2000,
              }}
              helperText="Minimum word count should be 2000"
            />
            <NumberInput
              handleChange={handleWordsPerMin}
              inputProps={{ min: 200 }}
              helperText="Minimum words per min should be 200"
            />
          </Box>
        )}
        {readerState !== "default" && <DisplayCard word={word} />}
        <Box className={classes.marginAutoContainer}>
          {readerState !== "started" && (
            <ActionButton
              isDisabled={
                !(
                  parseInt(wordCount) >= minWordCount &&
                  parseInt(wordPerMin) >= minWordPerMin
                )
              }
              handleButtonAction={startReader}
              label="Start"
            />
          )}
          {readerState === "started" && (
            <ActionButton
              isDisabled={false}
              handleButtonAction={stopReader}
              label="Stop"
            />
          )}
        </Box>
      </Container>
    </Box>
  );
};
export default SpeedReader;
