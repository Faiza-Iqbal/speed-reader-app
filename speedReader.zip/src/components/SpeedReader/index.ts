export { default } from "./SpeedReader";
